#!/bin/sh

gcc -W -fstack-protector -Wl,-z,relro,-z,now -m32 simple_login.c -o simple_login
