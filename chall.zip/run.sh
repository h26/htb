#!/bin/sh

socat tcp-listen:5053,reuseaddr,fork exec:./simple_login,pty,stderr
