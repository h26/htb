#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc,char * argv[]) {

char buffer[64] = {0};

int attemps = 0;

while(1) {

	if (attemps >= 2) {
		printf("Over!\n");
		break;
	}

	printf("login : ");
	fgets(buffer,63,stdin);
	buffer[strcspn(buffer,"\n")]=0;

	if (!strcmp(buffer,"superadmin")) { 
		printf("Welcome admin!\n");
		break;
	}
	attemps++;
	printf("\n");
	printf(buffer);
	printf(" is not the correct login.\n");
}

return 0;
}
